﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Library_DBMS
{
    public partial class Transactions_UserControl : UserControl
    {
        private static Transactions_UserControl _instance;
        public static Transactions_UserControl Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new Transactions_UserControl();
                }
                return _instance;
            }
        }
        public Transactions_UserControl()
        {
            InitializeComponent();
            


        }

        private void Transactions_UserControl_Load(object sender, EventArgs e)
        {
            refresh_DataGridView();
        }
        public string Book1, Book2, Borrower,BookID;

        SqlConnection con = new SqlConnection("Data Source = (LocalDB)\\MSSQLLocalDB; AttachDbFilename=\"|DataDirectory|\\Database.mdf\";Integrated Security = True");
        public SqlCommand cmd;
        public SqlDataReader dr;
        public SqlDataAdapter adpt;
         DataTable dt;

        public void refresh_DataGridView()
        {
            try
            {

                adpt = new SqlDataAdapter("select * from Transaction_Log", con);
                dt = new DataTable();
                adpt.Fill(dt);
                dataGridView1.DataSource = dt;
                

                con.Open();
                try
                {
                  
                }
                catch (Exception ex)
                {
                    MessageBox.Show("<<INVALID SQL OPERATION>>" + ex);
                }
                con.Close();
                this.dataGridView1.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
                this.dataGridView1.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                

            }
            catch (Exception ex)
            {
                MessageBox.Show("" + ex);
            }

        }


        private void Issue_book_button3_Click(object sender, EventArgs e)
        {
            SearchBorrowers_button.PerformClick();
            if (Borrower != "")
            {
                MessageBox.Show("Book is already borrowerd by someone else:\n" + Borrower);
                return;
            }
            SearchBorrowers_button.PerformClick();
            if ((Book1 != "") && (Book2 != ""))
            {
                MessageBox.Show("Borrower has already borrowed maximum number of books ");
                return;
            }

            try
            {
                if (Book1 == "")
                {
                    cmd = new SqlCommand("Transact_Update_Book1_SP", con);
                }
                else
                {
                    cmd = new SqlCommand("Transact_Update_Book2_SP", con);
                }
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@accNo", Acc_No_textBox1.Text);
                cmd.Parameters.AddWithValue("@brId", Borrower_ID_textBox2.Text);

                con.Open();
                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("<<INVALID SQL OPERATION>>\n" + ex);
                }
                con.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("" + ex);
            }
            cmd = new SqlCommand("Transact_Update_Borrowers_SP", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@accNo", Acc_No_textBox1.Text);
            cmd.Parameters.AddWithValue("@brId", Borrower_ID_textBox2.Text);

            con.Open();
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show("<<INVALID SQL OPERATION>>\n" + ex);
            }
            con.Close();


            cmd = new SqlCommand("transactions_insert_sp", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@bkid", Acc_No_textBox1.Text);
            cmd.Parameters.AddWithValue("@brid", Borrower_ID_textBox2.Text);

            con.Open();
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show("<<INVALID SQL OPERATION>>\n" + ex);
            }
            con.Close();

            Searchbook_button1.PerformClick();
            SearchBorrowers_button.PerformClick();
            MessageBox.Show("Successfully issued");
           

        }

        private void return_book_button4_Click(object sender, EventArgs e)
        {
            Searchbook_button1.PerformClick();
            SearchBorrowers_button.PerformClick();
            if ((Acc_No_textBox1.Text != Book1) && (Acc_No_textBox1.Text != Book2))
            {
                MessageBox.Show("The inputted borrower has not borrowed the book inputted");
                return;
            }

            try
            {
                if (Book1 == Acc_No_textBox1.Text)
                {
                    cmd = new SqlCommand("Transact_Update_Book1_SP", con);
                }
                else
                {
                    cmd = new SqlCommand("Transact_Update_Book2_SP", con);
                }
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@accNo", (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@brId", Borrower_ID_textBox2.Text);

                con.Open();
                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("<<INVALID SQL OPERATION>>\n" + ex);
                }
                con.Close();
            }

            catch (Exception ex)
            {
                MessageBox.Show("" + ex);
            }

            cmd = new SqlCommand("Transact_Update_Borrowers_SP", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@accNo", Acc_No_textBox1.Text);
            cmd.Parameters.AddWithValue("@brId", (object)DBNull.Value);

            con.Open();
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show("<<INVALID SQL OPERATION>>\n" + ex);
            }
            con.Close();


            cmd = new SqlCommand("transactions_delete_sp", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@bkid", Acc_No_textBox1.Text);
            cmd.Parameters.AddWithValue("@brid", Borrower_ID_textBox2.Text);

            con.Open();
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show("<<INVALID SQL OPERATION>>\n" + ex);
            }
            con.Close();

            Searchbook_button1.PerformClick();
            SearchBorrowers_button.PerformClick();
            MessageBox.Show("Successfully Returned");
            refresh_DataGridView();

        }





        private void Clear_all_button2_Click(object sender, EventArgs e)
        {
            Acc_No_textBox1.Text = "";
            Borrower_ID_textBox2.Text = "";
            Book1_label3.Text="";
            Book2_label4.Text= "";
            Borrowed_label6.Text= "";
            textBox1.Text = "";
            label1.Text = "";

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int days;
            float fine = 0;
            days = Convert.ToInt32(textBox1.Text);
            if (days <= 5)
            {
                fine = 0;
                label1.Text = "Your fine:" + fine + " Rs";
            }
            else if (days > 5 && days <= 10)
            {
                fine = (days - 5) * 0.5F;
                label1.Text = "Your fine:" + fine + " Rs";
            }
            else if (days > 10 && days <= 30)
            {
                //     ----5 days---   --between 10 and 30---
                fine = 5 * 0.5F + (days - 10) * 1;
                label1.Text = "Your fine:" + fine + " Rs";
            }
            else
            {
                //     -5 days-   -10 , 30-       -  >30  -
                fine = 5 * 0.5F + 20 * 1 + (days - 30) * 1.5F;
                label1.Text = "Canceled your Membership.\nYour fine:" + fine + " Rs";
            }

        }

        private void showlog_button_Click(object sender, EventArgs e)
        {

            //adpt = new SqlDataAdapter("select * from Transaction_Log", con);
            //dt = new DataTable();
            //adpt.Fill(dt);
            //dataGridView1.DataSource = dt;
            //this.dataGridView1.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            //this.dataGridView1.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            refresh_DataGridView();
        }



        private void Borrowed_label6_Click(object sender, EventArgs e)
        {

        }

        private void Searchbook_button1_Click(object sender, EventArgs e)
        {
            con.Open();
            String syntax = "SELECT borrower FROM Books where accNo= '" + Acc_No_textBox1.Text + "'";
            //String syntax = "SELECT borrower FROM Books where Name= '" + Acc_No_textBox1.Text + "'";
            cmd = new SqlCommand(syntax, con);
            dr = cmd.ExecuteReader();
            dr.Read();
            Borrowed_label6.Text = Borrower = dr[0].ToString();
            //label1.Text = BookID = dr[0].ToString(); 
            con.Close();
        }



        private void SearchBorrowers_button_Click(object sender, EventArgs e)
        {
            con.Open();
            String syntax = "SELECT Book1 FROM Borrowers where brId = '" + Borrower_ID_textBox2.Text + "'";
            cmd = new SqlCommand(syntax, con);
            dr = cmd.ExecuteReader();
            dr.Read();
            Book1_label3.Text = Book1 = dr[0].ToString();
            con.Close();

            con.Open();
            syntax = "SELECT Book2 FROM Borrowers where brId = '" + Borrower_ID_textBox2.Text + "'";
            cmd = new SqlCommand(syntax, con);
            dr = cmd.ExecuteReader();
            dr.Read();
            Book2_label4.Text = Book2 = dr[0].ToString();
            con.Close();


        }
    }
}
