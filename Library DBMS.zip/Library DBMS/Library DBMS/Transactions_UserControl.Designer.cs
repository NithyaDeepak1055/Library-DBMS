﻿namespace Library_DBMS
{
    partial class Transactions_UserControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.return_book_button4 = new System.Windows.Forms.Button();
            this.Issue_book_button3 = new System.Windows.Forms.Button();
            this.Clear_all_button2 = new System.Windows.Forms.Button();
            this.Searchbook_button1 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Acc_No_textBox1 = new System.Windows.Forms.TextBox();
            this.Acc_No_textBox2 = new System.Windows.Forms.TextBox();
            this.SearchBorrowers_button = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Borrower_ID_textBox2 = new System.Windows.Forms.TextBox();
            this.Borrower_ID_Box = new System.Windows.Forms.TextBox();
            this.Book1_label1 = new System.Windows.Forms.Label();
            this.Book2_label2 = new System.Windows.Forms.Label();
            this.Book1_label3 = new System.Windows.Forms.Label();
            this.Book2_label4 = new System.Windows.Forms.Label();
            this.Borrowed_by_label5 = new System.Windows.Forms.Label();
            this.Borrowed_label6 = new System.Windows.Forms.Label();
            this.showlog_button = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // return_book_button4
            // 
            this.return_book_button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.return_book_button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.return_book_button4.Font = new System.Drawing.Font("Microsoft YaHei", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.return_book_button4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.return_book_button4.Location = new System.Drawing.Point(758, 505);
            this.return_book_button4.Name = "return_book_button4";
            this.return_book_button4.Size = new System.Drawing.Size(189, 55);
            this.return_book_button4.TabIndex = 45;
            this.return_book_button4.Text = "Return Book";
            this.return_book_button4.UseVisualStyleBackColor = false;
            this.return_book_button4.Click += new System.EventHandler(this.return_book_button4_Click);
            // 
            // Issue_book_button3
            // 
            this.Issue_book_button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.Issue_book_button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Issue_book_button3.Font = new System.Drawing.Font("Microsoft YaHei", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Issue_book_button3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.Issue_book_button3.Location = new System.Drawing.Point(98, 505);
            this.Issue_book_button3.Name = "Issue_book_button3";
            this.Issue_book_button3.Size = new System.Drawing.Size(189, 55);
            this.Issue_book_button3.TabIndex = 44;
            this.Issue_book_button3.Text = "Issue Book";
            this.Issue_book_button3.UseVisualStyleBackColor = false;
            this.Issue_book_button3.Click += new System.EventHandler(this.Issue_book_button3_Click);
            // 
            // Clear_all_button2
            // 
            this.Clear_all_button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.Clear_all_button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Clear_all_button2.Font = new System.Drawing.Font("Microsoft YaHei", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Clear_all_button2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.Clear_all_button2.Location = new System.Drawing.Point(401, 414);
            this.Clear_all_button2.Name = "Clear_all_button2";
            this.Clear_all_button2.Size = new System.Drawing.Size(227, 52);
            this.Clear_all_button2.TabIndex = 43;
            this.Clear_all_button2.Text = "Clear All";
            this.Clear_all_button2.UseVisualStyleBackColor = false;
            this.Clear_all_button2.Click += new System.EventHandler(this.Clear_all_button2_Click);
            // 
            // Searchbook_button1
            // 
            this.Searchbook_button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.Searchbook_button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Searchbook_button1.Font = new System.Drawing.Font("Microsoft YaHei", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Searchbook_button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.Searchbook_button1.Location = new System.Drawing.Point(400, 249);
            this.Searchbook_button1.Name = "Searchbook_button1";
            this.Searchbook_button1.Size = new System.Drawing.Size(227, 52);
            this.Searchbook_button1.TabIndex = 42;
            this.Searchbook_button1.Text = "Search Book";
            this.Searchbook_button1.UseVisualStyleBackColor = false;
            this.Searchbook_button1.Click += new System.EventHandler(this.Searchbook_button1_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Cornsilk;
            this.panel2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.panel2.Location = new System.Drawing.Point(217, 230);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(559, 2);
            this.panel2.TabIndex = 41;
            // 
            // Acc_No_textBox1
            // 
            this.Acc_No_textBox1.BackColor = System.Drawing.Color.Cornsilk;
            this.Acc_No_textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Acc_No_textBox1.Location = new System.Drawing.Point(217, 206);
            this.Acc_No_textBox1.Name = "Acc_No_textBox1";
            this.Acc_No_textBox1.Size = new System.Drawing.Size(559, 19);
            this.Acc_No_textBox1.TabIndex = 40;
            // 
            // Acc_No_textBox2
            // 
            this.Acc_No_textBox2.BackColor = System.Drawing.Color.Cornsilk;
            this.Acc_No_textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Acc_No_textBox2.Font = new System.Drawing.Font("Microsoft YaHei", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Acc_No_textBox2.ForeColor = System.Drawing.Color.Black;
            this.Acc_No_textBox2.Location = new System.Drawing.Point(96, 206);
            this.Acc_No_textBox2.Name = "Acc_No_textBox2";
            this.Acc_No_textBox2.Size = new System.Drawing.Size(100, 30);
            this.Acc_No_textBox2.TabIndex = 39;
            this.Acc_No_textBox2.Text = "AccNo :";
            // 
            // SearchBorrowers_button
            // 
            this.SearchBorrowers_button.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.SearchBorrowers_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SearchBorrowers_button.Font = new System.Drawing.Font("Microsoft YaHei", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchBorrowers_button.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.SearchBorrowers_button.Location = new System.Drawing.Point(401, 124);
            this.SearchBorrowers_button.Name = "SearchBorrowers_button";
            this.SearchBorrowers_button.Size = new System.Drawing.Size(227, 53);
            this.SearchBorrowers_button.TabIndex = 38;
            this.SearchBorrowers_button.Text = "Search Borrowers";
            this.SearchBorrowers_button.UseVisualStyleBackColor = false;
            this.SearchBorrowers_button.Click += new System.EventHandler(this.SearchBorrowers_button_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Cornsilk;
            this.panel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.panel1.Location = new System.Drawing.Point(229, 96);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(559, 2);
            this.panel1.TabIndex = 37;
            // 
            // Borrower_ID_textBox2
            // 
            this.Borrower_ID_textBox2.BackColor = System.Drawing.Color.Cornsilk;
            this.Borrower_ID_textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Borrower_ID_textBox2.Location = new System.Drawing.Point(229, 72);
            this.Borrower_ID_textBox2.Name = "Borrower_ID_textBox2";
            this.Borrower_ID_textBox2.Size = new System.Drawing.Size(559, 19);
            this.Borrower_ID_textBox2.TabIndex = 36;
            // 
            // Borrower_ID_Box
            // 
            this.Borrower_ID_Box.BackColor = System.Drawing.Color.Cornsilk;
            this.Borrower_ID_Box.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Borrower_ID_Box.Font = new System.Drawing.Font("Microsoft YaHei", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Borrower_ID_Box.ForeColor = System.Drawing.Color.Black;
            this.Borrower_ID_Box.Location = new System.Drawing.Point(60, 68);
            this.Borrower_ID_Box.Name = "Borrower_ID_Box";
            this.Borrower_ID_Box.Size = new System.Drawing.Size(163, 30);
            this.Borrower_ID_Box.TabIndex = 35;
            this.Borrower_ID_Box.Text = "Borrower\'s ID:";
            // 
            // Book1_label1
            // 
            this.Book1_label1.AutoSize = true;
            this.Book1_label1.BackColor = System.Drawing.Color.Cornsilk;
            this.Book1_label1.ForeColor = System.Drawing.Color.Black;
            this.Book1_label1.Location = new System.Drawing.Point(821, 77);
            this.Book1_label1.Name = "Book1_label1";
            this.Book1_label1.Size = new System.Drawing.Size(59, 20);
            this.Book1_label1.TabIndex = 46;
            this.Book1_label1.Text = "Book 1";
            // 
            // Book2_label2
            // 
            this.Book2_label2.AutoSize = true;
            this.Book2_label2.BackColor = System.Drawing.Color.Cornsilk;
            this.Book2_label2.ForeColor = System.Drawing.Color.Black;
            this.Book2_label2.Location = new System.Drawing.Point(821, 112);
            this.Book2_label2.Name = "Book2_label2";
            this.Book2_label2.Size = new System.Drawing.Size(59, 20);
            this.Book2_label2.TabIndex = 47;
            this.Book2_label2.Text = "Book 2";
            // 
            // Book1_label3
            // 
            this.Book1_label3.AutoSize = true;
            this.Book1_label3.BackColor = System.Drawing.Color.Cornsilk;
            this.Book1_label3.ForeColor = System.Drawing.Color.Black;
            this.Book1_label3.Location = new System.Drawing.Point(914, 78);
            this.Book1_label3.Name = "Book1_label3";
            this.Book1_label3.Size = new System.Drawing.Size(97, 20);
            this.Book1_label3.TabIndex = 48;
            this.Book1_label3.Text = "Borrowed by";
            // 
            // Book2_label4
            // 
            this.Book2_label4.AutoSize = true;
            this.Book2_label4.BackColor = System.Drawing.Color.Cornsilk;
            this.Book2_label4.ForeColor = System.Drawing.Color.Black;
            this.Book2_label4.Location = new System.Drawing.Point(914, 112);
            this.Book2_label4.Name = "Book2_label4";
            this.Book2_label4.Size = new System.Drawing.Size(97, 20);
            this.Book2_label4.TabIndex = 49;
            this.Book2_label4.Text = "Borrowed by";
            // 
            // Borrowed_by_label5
            // 
            this.Borrowed_by_label5.AutoSize = true;
            this.Borrowed_by_label5.BackColor = System.Drawing.Color.Cornsilk;
            this.Borrowed_by_label5.ForeColor = System.Drawing.Color.Black;
            this.Borrowed_by_label5.Location = new System.Drawing.Point(820, 205);
            this.Borrowed_by_label5.Name = "Borrowed_by_label5";
            this.Borrowed_by_label5.Size = new System.Drawing.Size(97, 20);
            this.Borrowed_by_label5.TabIndex = 50;
            this.Borrowed_by_label5.Text = "Borrowed by";
            // 
            // Borrowed_label6
            // 
            this.Borrowed_label6.AutoSize = true;
            this.Borrowed_label6.BackColor = System.Drawing.Color.Cornsilk;
            this.Borrowed_label6.ForeColor = System.Drawing.Color.Black;
            this.Borrowed_label6.Location = new System.Drawing.Point(929, 206);
            this.Borrowed_label6.Name = "Borrowed_label6";
            this.Borrowed_label6.Size = new System.Drawing.Size(81, 20);
            this.Borrowed_label6.TabIndex = 51;
            this.Borrowed_label6.Text = "Borrowed ";
            this.Borrowed_label6.Click += new System.EventHandler(this.Borrowed_label6_Click);
            // 
            // showlog_button
            // 
            this.showlog_button.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.showlog_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.showlog_button.Font = new System.Drawing.Font("Microsoft YaHei", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.showlog_button.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.showlog_button.Location = new System.Drawing.Point(388, 505);
            this.showlog_button.Name = "showlog_button";
            this.showlog_button.Size = new System.Drawing.Size(271, 55);
            this.showlog_button.TabIndex = 52;
            this.showlog_button.Text = "Show log of tran";
            this.showlog_button.UseVisualStyleBackColor = false;
            this.showlog_button.Click += new System.EventHandler(this.showlog_button_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.Cornsilk;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.GridColor = System.Drawing.Color.Black;
            this.dataGridView1.Location = new System.Drawing.Point(32, 599);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(1016, 64);
            this.dataGridView1.TabIndex = 53;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Cornsilk;
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(821, 342);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 20);
            this.label1.TabIndex = 57;
            this.label1.Text = "Fine";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Cornsilk;
            this.panel3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.panel3.Location = new System.Drawing.Point(250, 366);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(300, 2);
            this.panel3.TabIndex = 56;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Location = new System.Drawing.Point(250, 342);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(300, 19);
            this.textBox1.TabIndex = 55;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox2.Font = new System.Drawing.Font("Microsoft YaHei", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.ForeColor = System.Drawing.Color.Black;
            this.textBox2.Location = new System.Drawing.Point(87, 342);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(136, 30);
            this.textBox2.TabIndex = 54;
            this.textBox2.Text = "Total Days :";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft YaHei", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.button1.Location = new System.Drawing.Point(575, 331);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(227, 52);
            this.button1.TabIndex = 58;
            this.button1.Text = "Calculate";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Transactions_UserControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.BackgroundImage = global::Library_DBMS.Properties.Resources.l17;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.showlog_button);
            this.Controls.Add(this.Borrowed_label6);
            this.Controls.Add(this.Borrowed_by_label5);
            this.Controls.Add(this.Book2_label4);
            this.Controls.Add(this.Book1_label3);
            this.Controls.Add(this.Book2_label2);
            this.Controls.Add(this.Book1_label1);
            this.Controls.Add(this.return_book_button4);
            this.Controls.Add(this.Issue_book_button3);
            this.Controls.Add(this.Clear_all_button2);
            this.Controls.Add(this.Searchbook_button1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.Acc_No_textBox1);
            this.Controls.Add(this.Acc_No_textBox2);
            this.Controls.Add(this.SearchBorrowers_button);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Borrower_ID_textBox2);
            this.Controls.Add(this.Borrower_ID_Box);
            this.Name = "Transactions_UserControl";
            this.Size = new System.Drawing.Size(1076, 681);
            this.Load += new System.EventHandler(this.Transactions_UserControl_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button return_book_button4;
        private System.Windows.Forms.Button Issue_book_button3;
        private System.Windows.Forms.Button Clear_all_button2;
        private System.Windows.Forms.Button Searchbook_button1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox Acc_No_textBox1;
        private System.Windows.Forms.TextBox Acc_No_textBox2;
        private System.Windows.Forms.Button SearchBorrowers_button;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox Borrower_ID_textBox2;
        private System.Windows.Forms.TextBox Borrower_ID_Box;
        private System.Windows.Forms.Label Book1_label1;
        private System.Windows.Forms.Label Book2_label2;
        private System.Windows.Forms.Label Book1_label3;
        private System.Windows.Forms.Label Book2_label4;
        private System.Windows.Forms.Label Borrowed_by_label5;
        private System.Windows.Forms.Label Borrowed_label6;
        private System.Windows.Forms.Button showlog_button;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button button1;
    }
}
