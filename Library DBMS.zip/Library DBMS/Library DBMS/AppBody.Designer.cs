﻿namespace Library_DBMS
{
    partial class AppBody
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AppBody));
            this.Slidingpanel = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.About_button = new System.Windows.Forms.Button();
            this.SlidingPanel_Togglebutton = new System.Windows.Forms.Button();
            this.Books_button = new System.Windows.Forms.Button();
            this.Transactions_button = new System.Windows.Forms.Button();
            this.Borrowers_button = new System.Windows.Forms.Button();
            this.SlidingPanel_timer = new System.Windows.Forms.Timer(this.components);
            this.Contentpanel = new System.Windows.Forms.Panel();
            this.Slidingpanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // Slidingpanel
            // 
            this.Slidingpanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.Slidingpanel.Controls.Add(this.button1);
            this.Slidingpanel.Controls.Add(this.About_button);
            this.Slidingpanel.Controls.Add(this.SlidingPanel_Togglebutton);
            this.Slidingpanel.Controls.Add(this.Books_button);
            this.Slidingpanel.Controls.Add(this.Transactions_button);
            this.Slidingpanel.Controls.Add(this.Borrowers_button);
            this.Slidingpanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.Slidingpanel.Location = new System.Drawing.Point(0, 0);
            this.Slidingpanel.Name = "Slidingpanel";
            this.Slidingpanel.Size = new System.Drawing.Size(211, 681);
            this.Slidingpanel.TabIndex = 0;
            this.Slidingpanel.Paint += new System.Windows.Forms.PaintEventHandler(this.Slidingpanel_Paint);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft YaHei UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(4)))), ((int)(((byte)(36)))));
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(0, 474);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(210, 88);
            this.button1.TabIndex = 7;
            this.button1.Text = "LOGOUT";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // About_button
            // 
            this.About_button.BackColor = System.Drawing.Color.Transparent;
            this.About_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.About_button.Font = new System.Drawing.Font("Microsoft YaHei UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.About_button.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(4)))), ((int)(((byte)(36)))));
            this.About_button.Image = global::Library_DBMS.Properties.Resources.About;
            this.About_button.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.About_button.Location = new System.Drawing.Point(0, 351);
            this.About_button.Name = "About_button";
            this.About_button.Size = new System.Drawing.Size(210, 88);
            this.About_button.TabIndex = 6;
            this.About_button.Text = "ABOUT";
            this.About_button.UseVisualStyleBackColor = false;
            this.About_button.Click += new System.EventHandler(this.About_button_Click);
            // 
            // SlidingPanel_Togglebutton
            // 
            this.SlidingPanel_Togglebutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SlidingPanel_Togglebutton.Image = global::Library_DBMS.Properties.Resources.left_arrow;
            this.SlidingPanel_Togglebutton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SlidingPanel_Togglebutton.Location = new System.Drawing.Point(0, 0);
            this.SlidingPanel_Togglebutton.Name = "SlidingPanel_Togglebutton";
            this.SlidingPanel_Togglebutton.Size = new System.Drawing.Size(210, 90);
            this.SlidingPanel_Togglebutton.TabIndex = 1;
            this.SlidingPanel_Togglebutton.UseVisualStyleBackColor = true;
            this.SlidingPanel_Togglebutton.Click += new System.EventHandler(this.SlidingPanel_Togglebutton_Click);
            // 
            // Books_button
            // 
            this.Books_button.BackColor = System.Drawing.Color.Transparent;
            this.Books_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Books_button.Font = new System.Drawing.Font("Microsoft YaHei UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Books_button.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(4)))), ((int)(((byte)(36)))));
            this.Books_button.Image = global::Library_DBMS.Properties.Resources.Book;
            this.Books_button.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Books_button.Location = new System.Drawing.Point(0, 97);
            this.Books_button.Name = "Books_button";
            this.Books_button.Size = new System.Drawing.Size(210, 88);
            this.Books_button.TabIndex = 2;
            this.Books_button.Text = "BOOKS";
            this.Books_button.UseVisualStyleBackColor = false;
            this.Books_button.Click += new System.EventHandler(this.Books_button_Click);
            // 
            // Transactions_button
            // 
            this.Transactions_button.BackColor = System.Drawing.Color.Transparent;
            this.Transactions_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Transactions_button.Font = new System.Drawing.Font("Microsoft YaHei UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Transactions_button.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(4)))), ((int)(((byte)(36)))));
            this.Transactions_button.Image = global::Library_DBMS.Properties.Resources.transactions;
            this.Transactions_button.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Transactions_button.Location = new System.Drawing.Point(0, 267);
            this.Transactions_button.Name = "Transactions_button";
            this.Transactions_button.Size = new System.Drawing.Size(210, 88);
            this.Transactions_button.TabIndex = 4;
            this.Transactions_button.Text = "TRANSACTIONS";
            this.Transactions_button.UseVisualStyleBackColor = false;
            this.Transactions_button.Click += new System.EventHandler(this.Transactions_button_Click);
            // 
            // Borrowers_button
            // 
            this.Borrowers_button.BackColor = System.Drawing.Color.Transparent;
            this.Borrowers_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Borrowers_button.Font = new System.Drawing.Font("Microsoft YaHei UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Borrowers_button.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(4)))), ((int)(((byte)(36)))));
            this.Borrowers_button.Image = global::Library_DBMS.Properties.Resources.Borrowers;
            this.Borrowers_button.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Borrowers_button.Location = new System.Drawing.Point(0, 182);
            this.Borrowers_button.Name = "Borrowers_button";
            this.Borrowers_button.Size = new System.Drawing.Size(210, 88);
            this.Borrowers_button.TabIndex = 3;
            this.Borrowers_button.Text = "BORROWERS";
            this.Borrowers_button.UseVisualStyleBackColor = false;
            this.Borrowers_button.Click += new System.EventHandler(this.Borrowers_button_Click);
            // 
            // SlidingPanel_timer
            // 
            this.SlidingPanel_timer.Tick += new System.EventHandler(this.SlidingPanel_timer_Tick);
            // 
            // Contentpanel
            // 
            this.Contentpanel.BackColor = System.Drawing.Color.Transparent;
            this.Contentpanel.Dock = System.Windows.Forms.DockStyle.Right;
            this.Contentpanel.Location = new System.Drawing.Point(208, 0);
            this.Contentpanel.Name = "Contentpanel";
            this.Contentpanel.Size = new System.Drawing.Size(1076, 681);
            this.Contentpanel.TabIndex = 1;
            this.Contentpanel.Paint += new System.Windows.Forms.PaintEventHandler(this.Contentpanel_Paint);
            // 
            // AppBody
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Library_DBMS.Properties.Resources.Welcome;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1284, 681);
            this.Controls.Add(this.Contentpanel);
            this.Controls.Add(this.Slidingpanel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AppBody";
            this.Text = "Library Management System";
            this.Load += new System.EventHandler(this.AppBody_Load);
            this.Slidingpanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel Slidingpanel;
        private System.Windows.Forms.Button SlidingPanel_Togglebutton;
        private System.Windows.Forms.Button Books_button;
        private System.Windows.Forms.Button Borrowers_button;
        private System.Windows.Forms.Button Transactions_button;
        private System.Windows.Forms.Button About_button;
        private System.Windows.Forms.Timer SlidingPanel_timer;
        private System.Windows.Forms.Panel Contentpanel;
        private System.Windows.Forms.Button button1;
    }
}