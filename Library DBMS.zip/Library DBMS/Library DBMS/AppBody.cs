﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library_DBMS
{
    public partial class AppBody : Form
    {
        public AppBody()
        {
            InitializeComponent();
            isSlidingPanelExpanded = true;
            expandSlidingPanelGUI();
        }

        bool isSlidingPanelExpanded;
        const int MaxSliderWidth = 135;
        const int MinSliderWidth = 100;

        public void expandSlidingPanelGUI()
        {
            //GUI Adjustments
            Books_button.Text = "BOOKS";
            Borrowers_button.Text = "BORROWERS";
            Transactions_button.Text = "TRANSACTIONS";
            About_button.Text = "ABOUT";
            SlidingPanel_Togglebutton.Image = Properties.Resources.left_arrow;
            Books_button.Image = null;
            Borrowers_button.Image = null;
            Transactions_button.Image = null;
            About_button.Image = null;
        }

        public void retractSlidingPanelGUI()
        {
            //GUI Adjustments
            Books_button.Text = "";
            Borrowers_button.Text = "";
            Transactions_button.Text = "";
            About_button.Text = "";
            SlidingPanel_Togglebutton.Image = Properties.Resources.right_arrow;
            Books_button.Image = Properties.Resources.Book;
            Borrowers_button.Image = Properties.Resources.Borrowers;
            Transactions_button.Image = Properties.Resources.transactions;
            About_button.Image = Properties.Resources.About;
        }
        private void SlidingPanel_Togglebutton_Click(object sender, EventArgs e)
        {
            if (isSlidingPanelExpanded)
            {
                //retractSlidingPanelGUI();
            }
            SlidingPanel_timer.Start();

        }

        private void SlidingPanel_timer_Tick(object sender, EventArgs e)
        {
            if (isSlidingPanelExpanded)
            {
                //retract panel
                Slidingpanel.Width -= 30;
                if (Slidingpanel.Width <= MinSliderWidth)
                {
                    //stop retract
                    isSlidingPanelExpanded = false;
                    SlidingPanel_timer.Stop();
                    retractSlidingPanelGUI();
                    this.Refresh();

                }
            }
            else
            {
                //expand the panel
                Slidingpanel.Width += 30;
                if (Slidingpanel.Width >= MaxSliderWidth)
                {
                    //stop expanding
                    isSlidingPanelExpanded = true;
                    SlidingPanel_timer.Stop();
                    expandSlidingPanelGUI();
                    this.Refresh();

                }


            }
        }

        private void Books_button_Click(object sender, EventArgs e)
        {
            if (!Contentpanel.Controls.Contains(Books_UserControl.Instance))
            {
                Contentpanel.Controls.Add(Books_UserControl.Instance);
                Books_UserControl.Instance.Dock = DockStyle.Fill;
                Books_UserControl.Instance.BringToFront();
            }
            else
            {
                Books_UserControl.Instance.BringToFront();
            }
        }

        private void Borrowers_button_Click(object sender, EventArgs e)
        {
            if (!Contentpanel.Controls.Contains(Borrowers_UserControl.Instance))
            {
                Contentpanel.Controls.Add(Borrowers_UserControl.Instance);
                Borrowers_UserControl.Instance.Dock = DockStyle.Fill;
                Borrowers_UserControl.Instance.BringToFront();
            }
            else
            {
                Borrowers_UserControl.Instance.BringToFront();
            }
        }

        private void Transactions_button_Click(object sender, EventArgs e)
        {
            if (!Contentpanel.Controls.Contains(Transactions_UserControl.Instance))
            {
                Contentpanel.Controls.Add(Transactions_UserControl.Instance);
                Transactions_UserControl.Instance.Dock = DockStyle.Fill;
                Transactions_UserControl.Instance.BringToFront();
            }
            else
            {
                Transactions_UserControl.Instance.BringToFront();
            }

        }

        private void Settings_button_Click(object sender, EventArgs e)
        {
            //if (!Contentpanel.Controls.Contains(Settings_UserControl.Instance))
            //{
                //Contentpanel.Controls.Add(Settings_UserControl.Instance);
               // Settings_UserControl.Instance.Dock = DockStyle.Fill;
               // Settings_UserControl.Instance.BringToFront();
            //}
           // else
            //{
                //Settings_UserControl.Instance.BringToFront();
           // }

        }

        private void About_button_Click(object sender, EventArgs e)
        {
            if (!Contentpanel.Controls.Contains(About_UserControl.Instance))
            {
                Contentpanel.Controls.Add(About_UserControl.Instance);
                About_UserControl.Instance.Dock = DockStyle.Fill;
                About_UserControl.Instance.BringToFront();
            }
            else
            {
                About_UserControl.Instance.BringToFront();
            }

        }

        private void Contentpanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void AppBody_Load(object sender, EventArgs e)
        {

        }

        private void Slidingpanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Form1 obj = new Form1();
            this.Hide();
            obj.Show();
        }
    }
}
