﻿namespace Library_DBMS
{
    partial class Borrowers_UserControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Clear_button = new System.Windows.Forms.Button();
            this.Delete_button = new System.Windows.Forms.Button();
            this.AddNew_button = new System.Windows.Forms.Button();
            this.SearchBorrower_button = new System.Windows.Forms.Button();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.Address_textBox = new System.Windows.Forms.TextBox();
            this.Address_Box = new System.Windows.Forms.TextBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.Name_textBox = new System.Windows.Forms.TextBox();
            this.Name_Box = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Borrower_No_textBox = new System.Windows.Forms.TextBox();
            this.BookID_Box = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel27 = new System.Windows.Forms.Panel();
            this.panel28 = new System.Windows.Forms.Panel();
            this.panel29 = new System.Windows.Forms.Panel();
            this.panel30 = new System.Windows.Forms.Panel();
            this.panel31 = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.Book1_textBox = new System.Windows.Forms.TextBox();
            this.Book1_Box = new System.Windows.Forms.TextBox();
            this.panel32 = new System.Windows.Forms.Panel();
            this.panel33 = new System.Windows.Forms.Panel();
            this.panel34 = new System.Windows.Forms.Panel();
            this.panel35 = new System.Windows.Forms.Panel();
            this.panel36 = new System.Windows.Forms.Panel();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.Phone_textBox = new System.Windows.Forms.TextBox();
            this.Phone_Box = new System.Windows.Forms.TextBox();
            this.panel37 = new System.Windows.Forms.Panel();
            this.panel38 = new System.Windows.Forms.Panel();
            this.panel39 = new System.Windows.Forms.Panel();
            this.panel40 = new System.Windows.Forms.Panel();
            this.panel41 = new System.Windows.Forms.Panel();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.textBox49 = new System.Windows.Forms.TextBox();
            this.textBox50 = new System.Windows.Forms.TextBox();
            this.Book2_textBox = new System.Windows.Forms.TextBox();
            this.Book2_Box = new System.Windows.Forms.TextBox();
            this.panel52 = new System.Windows.Forms.Panel();
            this.panel53 = new System.Windows.Forms.Panel();
            this.panel54 = new System.Windows.Forms.Panel();
            this.panel55 = new System.Windows.Forms.Panel();
            this.panel56 = new System.Windows.Forms.Panel();
            this.textBox72 = new System.Windows.Forms.TextBox();
            this.textBox73 = new System.Windows.Forms.TextBox();
            this.textBox74 = new System.Windows.Forms.TextBox();
            this.textBox75 = new System.Windows.Forms.TextBox();
            this.textBox76 = new System.Windows.Forms.TextBox();
            this.textBox77 = new System.Windows.Forms.TextBox();
            this.Br_id_textBox = new System.Windows.Forms.TextBox();
            this.Br_ID_Box = new System.Windows.Forms.TextBox();
            this.panel12.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel27.SuspendLayout();
            this.panel28.SuspendLayout();
            this.panel29.SuspendLayout();
            this.panel30.SuspendLayout();
            this.panel32.SuspendLayout();
            this.panel33.SuspendLayout();
            this.panel34.SuspendLayout();
            this.panel35.SuspendLayout();
            this.panel37.SuspendLayout();
            this.panel38.SuspendLayout();
            this.panel39.SuspendLayout();
            this.panel40.SuspendLayout();
            this.panel52.SuspendLayout();
            this.panel53.SuspendLayout();
            this.panel54.SuspendLayout();
            this.panel55.SuspendLayout();
            this.SuspendLayout();
            // 
            // Clear_button
            // 
            this.Clear_button.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.Clear_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Clear_button.Font = new System.Drawing.Font("Microsoft YaHei", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Clear_button.ForeColor = System.Drawing.Color.Black;
            this.Clear_button.Location = new System.Drawing.Point(836, 347);
            this.Clear_button.Name = "Clear_button";
            this.Clear_button.Size = new System.Drawing.Size(184, 50);
            this.Clear_button.TabIndex = 49;
            this.Clear_button.Text = "Clear";
            this.Clear_button.UseVisualStyleBackColor = false;
            this.Clear_button.Click += new System.EventHandler(this.Clear_button_Click);
            // 
            // Delete_button
            // 
            this.Delete_button.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.Delete_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Delete_button.Font = new System.Drawing.Font("Microsoft YaHei", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Delete_button.ForeColor = System.Drawing.Color.Black;
            this.Delete_button.Location = new System.Drawing.Point(452, 347);
            this.Delete_button.Name = "Delete_button";
            this.Delete_button.Size = new System.Drawing.Size(184, 50);
            this.Delete_button.TabIndex = 48;
            this.Delete_button.Text = "Delete";
            this.Delete_button.UseVisualStyleBackColor = false;
            this.Delete_button.Click += new System.EventHandler(this.Delete_button_Click);
            // 
            // AddNew_button
            // 
            this.AddNew_button.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.AddNew_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddNew_button.Font = new System.Drawing.Font("Microsoft YaHei", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddNew_button.ForeColor = System.Drawing.Color.Black;
            this.AddNew_button.Location = new System.Drawing.Point(55, 347);
            this.AddNew_button.Name = "AddNew_button";
            this.AddNew_button.Size = new System.Drawing.Size(184, 50);
            this.AddNew_button.TabIndex = 47;
            this.AddNew_button.Text = "Add new";
            this.AddNew_button.UseVisualStyleBackColor = false;
            this.AddNew_button.Click += new System.EventHandler(this.AddNew_button_Click);
            // 
            // SearchBorrower_button
            // 
            this.SearchBorrower_button.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.SearchBorrower_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SearchBorrower_button.Font = new System.Drawing.Font("Microsoft YaHei", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchBorrower_button.ForeColor = System.Drawing.Color.Black;
            this.SearchBorrower_button.Location = new System.Drawing.Point(728, 14);
            this.SearchBorrower_button.Name = "SearchBorrower_button";
            this.SearchBorrower_button.Size = new System.Drawing.Size(238, 45);
            this.SearchBorrower_button.TabIndex = 46;
            this.SearchBorrower_button.Text = "Search Borrower";
            this.SearchBorrower_button.UseVisualStyleBackColor = false;
            this.SearchBorrower_button.Click += new System.EventHandler(this.SearchBorrower_button_Click);
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.Black;
            this.panel12.Controls.Add(this.panel13);
            this.panel12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.panel12.Location = new System.Drawing.Point(172, 538);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(160, 2);
            this.panel12.TabIndex = 39;
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.panel14);
            this.panel13.Controls.Add(this.textBox27);
            this.panel13.Controls.Add(this.textBox28);
            this.panel13.ForeColor = System.Drawing.Color.Yellow;
            this.panel13.Location = new System.Drawing.Point(60, 12);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(459, 2);
            this.panel13.TabIndex = 5;
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.panel15);
            this.panel14.Controls.Add(this.textBox25);
            this.panel14.Controls.Add(this.textBox26);
            this.panel14.ForeColor = System.Drawing.Color.Yellow;
            this.panel14.Location = new System.Drawing.Point(60, 12);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(459, 2);
            this.panel14.TabIndex = 5;
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.panel16);
            this.panel15.Controls.Add(this.textBox23);
            this.panel15.Controls.Add(this.textBox24);
            this.panel15.ForeColor = System.Drawing.Color.Yellow;
            this.panel15.Location = new System.Drawing.Point(60, 12);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(459, 2);
            this.panel15.TabIndex = 5;
            // 
            // panel16
            // 
            this.panel16.ForeColor = System.Drawing.Color.Yellow;
            this.panel16.Location = new System.Drawing.Point(60, 12);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(459, 2);
            this.panel16.TabIndex = 5;
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(60, -12);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(459, 26);
            this.textBox23.TabIndex = 4;
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(-61, -12);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(100, 26);
            this.textBox24.TabIndex = 3;
            this.textBox24.Text = "Book ID:";
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(60, -12);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(459, 26);
            this.textBox25.TabIndex = 4;
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(-61, -12);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(100, 26);
            this.textBox26.TabIndex = 3;
            this.textBox26.Text = "Book ID:";
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(60, -12);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(459, 26);
            this.textBox27.TabIndex = 4;
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(-61, -12);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(100, 26);
            this.textBox28.TabIndex = 3;
            this.textBox28.Text = "Book ID:";
            // 
            // Address_textBox
            // 
            this.Address_textBox.BackColor = System.Drawing.Color.White;
            this.Address_textBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Address_textBox.Location = new System.Drawing.Point(172, 514);
            this.Address_textBox.Name = "Address_textBox";
            this.Address_textBox.Size = new System.Drawing.Size(160, 19);
            this.Address_textBox.TabIndex = 38;
            // 
            // Address_Box
            // 
            this.Address_Box.BackColor = System.Drawing.Color.White;
            this.Address_Box.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Address_Box.Font = new System.Drawing.Font("Microsoft YaHei", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Address_Box.ForeColor = System.Drawing.Color.Black;
            this.Address_Box.Location = new System.Drawing.Point(37, 514);
            this.Address_Box.Name = "Address_Box";
            this.Address_Box.Size = new System.Drawing.Size(115, 30);
            this.Address_Box.TabIndex = 37;
            this.Address_Box.Text = "Address :";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Black;
            this.panel7.Controls.Add(this.panel8);
            this.panel7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.panel7.Location = new System.Drawing.Point(172, 499);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(160, 2);
            this.panel7.TabIndex = 36;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.panel9);
            this.panel8.Controls.Add(this.textBox17);
            this.panel8.Controls.Add(this.textBox18);
            this.panel8.ForeColor = System.Drawing.Color.Yellow;
            this.panel8.Location = new System.Drawing.Point(60, 12);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(459, 2);
            this.panel8.TabIndex = 5;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.panel10);
            this.panel9.Controls.Add(this.textBox15);
            this.panel9.Controls.Add(this.textBox16);
            this.panel9.ForeColor = System.Drawing.Color.Yellow;
            this.panel9.Location = new System.Drawing.Point(60, 12);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(459, 2);
            this.panel9.TabIndex = 5;
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.panel11);
            this.panel10.Controls.Add(this.textBox13);
            this.panel10.Controls.Add(this.textBox14);
            this.panel10.ForeColor = System.Drawing.Color.Yellow;
            this.panel10.Location = new System.Drawing.Point(60, 12);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(459, 2);
            this.panel10.TabIndex = 5;
            // 
            // panel11
            // 
            this.panel11.ForeColor = System.Drawing.Color.Yellow;
            this.panel11.Location = new System.Drawing.Point(60, 12);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(459, 2);
            this.panel11.TabIndex = 5;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(60, -12);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(459, 26);
            this.textBox13.TabIndex = 4;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(-61, -12);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(100, 26);
            this.textBox14.TabIndex = 3;
            this.textBox14.Text = "Book ID:";
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(60, -12);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(459, 26);
            this.textBox15.TabIndex = 4;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(-61, -12);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(100, 26);
            this.textBox16.TabIndex = 3;
            this.textBox16.Text = "Book ID:";
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(60, -12);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(459, 26);
            this.textBox17.TabIndex = 4;
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(-61, -12);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(100, 26);
            this.textBox18.TabIndex = 3;
            this.textBox18.Text = "Book ID:";
            // 
            // Name_textBox
            // 
            this.Name_textBox.BackColor = System.Drawing.Color.White;
            this.Name_textBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Name_textBox.Location = new System.Drawing.Point(172, 475);
            this.Name_textBox.Name = "Name_textBox";
            this.Name_textBox.Size = new System.Drawing.Size(160, 19);
            this.Name_textBox.TabIndex = 35;
            // 
            // Name_Box
            // 
            this.Name_Box.BackColor = System.Drawing.Color.White;
            this.Name_Box.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Name_Box.Font = new System.Drawing.Font("Microsoft YaHei", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name_Box.ForeColor = System.Drawing.Color.Black;
            this.Name_Box.Location = new System.Drawing.Point(51, 475);
            this.Name_Box.Name = "Name_Box";
            this.Name_Box.Size = new System.Drawing.Size(100, 30);
            this.Name_Box.TabIndex = 34;
            this.Name_Box.Text = "Name :";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.panel1.Location = new System.Drawing.Point(217, 45);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(459, 2);
            this.panel1.TabIndex = 30;
            // 
            // Borrower_No_textBox
            // 
            this.Borrower_No_textBox.BackColor = System.Drawing.Color.White;
            this.Borrower_No_textBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Borrower_No_textBox.Location = new System.Drawing.Point(217, 21);
            this.Borrower_No_textBox.Name = "Borrower_No_textBox";
            this.Borrower_No_textBox.Size = new System.Drawing.Size(459, 19);
            this.Borrower_No_textBox.TabIndex = 29;
            // 
            // BookID_Box
            // 
            this.BookID_Box.BackColor = System.Drawing.Color.White;
            this.BookID_Box.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.BookID_Box.Font = new System.Drawing.Font("Microsoft YaHei", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BookID_Box.ForeColor = System.Drawing.Color.Black;
            this.BookID_Box.Location = new System.Drawing.Point(55, 21);
            this.BookID_Box.Name = "BookID_Box";
            this.BookID_Box.Size = new System.Drawing.Size(142, 30);
            this.BookID_Box.TabIndex = 28;
            this.BookID_Box.Text = "Borrower No:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.GridColor = System.Drawing.Color.Black;
            this.dataGridView1.Location = new System.Drawing.Point(26, 79);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(1016, 250);
            this.dataGridView1.TabIndex = 50;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // panel27
            // 
            this.panel27.BackColor = System.Drawing.Color.Black;
            this.panel27.Controls.Add(this.panel28);
            this.panel27.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.panel27.Location = new System.Drawing.Point(711, 506);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(160, 2);
            this.panel27.TabIndex = 56;
            // 
            // panel28
            // 
            this.panel28.Controls.Add(this.panel29);
            this.panel28.Controls.Add(this.textBox5);
            this.panel28.Controls.Add(this.textBox6);
            this.panel28.ForeColor = System.Drawing.Color.Yellow;
            this.panel28.Location = new System.Drawing.Point(60, 12);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(459, 2);
            this.panel28.TabIndex = 5;
            // 
            // panel29
            // 
            this.panel29.Controls.Add(this.panel30);
            this.panel29.Controls.Add(this.textBox3);
            this.panel29.Controls.Add(this.textBox4);
            this.panel29.ForeColor = System.Drawing.Color.Yellow;
            this.panel29.Location = new System.Drawing.Point(60, 12);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(459, 2);
            this.panel29.TabIndex = 5;
            // 
            // panel30
            // 
            this.panel30.Controls.Add(this.panel31);
            this.panel30.Controls.Add(this.textBox1);
            this.panel30.Controls.Add(this.textBox2);
            this.panel30.ForeColor = System.Drawing.Color.Yellow;
            this.panel30.Location = new System.Drawing.Point(60, 12);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(459, 2);
            this.panel30.TabIndex = 5;
            // 
            // panel31
            // 
            this.panel31.ForeColor = System.Drawing.Color.Yellow;
            this.panel31.Location = new System.Drawing.Point(60, 12);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(459, 2);
            this.panel31.TabIndex = 5;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(60, -12);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(459, 26);
            this.textBox1.TabIndex = 4;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(-61, -12);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 26);
            this.textBox2.TabIndex = 3;
            this.textBox2.Text = "Book ID:";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(60, -12);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(459, 26);
            this.textBox3.TabIndex = 4;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(-61, -12);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 26);
            this.textBox4.TabIndex = 3;
            this.textBox4.Text = "Book ID:";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(60, -12);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(459, 26);
            this.textBox5.TabIndex = 4;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(-61, -12);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 26);
            this.textBox6.TabIndex = 3;
            this.textBox6.Text = "Book ID:";
            // 
            // Book1_textBox
            // 
            this.Book1_textBox.BackColor = System.Drawing.Color.White;
            this.Book1_textBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Book1_textBox.Location = new System.Drawing.Point(711, 482);
            this.Book1_textBox.Name = "Book1_textBox";
            this.Book1_textBox.Size = new System.Drawing.Size(160, 19);
            this.Book1_textBox.TabIndex = 55;
            // 
            // Book1_Box
            // 
            this.Book1_Box.BackColor = System.Drawing.Color.White;
            this.Book1_Box.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Book1_Box.Font = new System.Drawing.Font("Microsoft YaHei", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Book1_Box.ForeColor = System.Drawing.Color.Black;
            this.Book1_Box.Location = new System.Drawing.Point(586, 482);
            this.Book1_Box.Name = "Book1_Box";
            this.Book1_Box.Size = new System.Drawing.Size(103, 30);
            this.Book1_Box.TabIndex = 54;
            this.Book1_Box.Text = "Book 1 :";
            // 
            // panel32
            // 
            this.panel32.BackColor = System.Drawing.Color.Black;
            this.panel32.Controls.Add(this.panel33);
            this.panel32.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.panel32.Location = new System.Drawing.Point(171, 582);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(160, 2);
            this.panel32.TabIndex = 53;
            // 
            // panel33
            // 
            this.panel33.Controls.Add(this.panel34);
            this.panel33.Controls.Add(this.textBox31);
            this.panel33.Controls.Add(this.textBox32);
            this.panel33.ForeColor = System.Drawing.Color.Yellow;
            this.panel33.Location = new System.Drawing.Point(60, 12);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(459, 2);
            this.panel33.TabIndex = 5;
            // 
            // panel34
            // 
            this.panel34.Controls.Add(this.panel35);
            this.panel34.Controls.Add(this.textBox29);
            this.panel34.Controls.Add(this.textBox30);
            this.panel34.ForeColor = System.Drawing.Color.Yellow;
            this.panel34.Location = new System.Drawing.Point(60, 12);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(459, 2);
            this.panel34.TabIndex = 5;
            // 
            // panel35
            // 
            this.panel35.Controls.Add(this.panel36);
            this.panel35.Controls.Add(this.textBox21);
            this.panel35.Controls.Add(this.textBox22);
            this.panel35.ForeColor = System.Drawing.Color.Yellow;
            this.panel35.Location = new System.Drawing.Point(60, 12);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(459, 2);
            this.panel35.TabIndex = 5;
            // 
            // panel36
            // 
            this.panel36.ForeColor = System.Drawing.Color.Yellow;
            this.panel36.Location = new System.Drawing.Point(60, 12);
            this.panel36.Name = "panel36";
            this.panel36.Size = new System.Drawing.Size(459, 2);
            this.panel36.TabIndex = 5;
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(60, -12);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(459, 26);
            this.textBox21.TabIndex = 4;
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(-61, -12);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(100, 26);
            this.textBox22.TabIndex = 3;
            this.textBox22.Text = "Book ID:";
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(60, -12);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(459, 26);
            this.textBox29.TabIndex = 4;
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(-61, -12);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(100, 26);
            this.textBox30.TabIndex = 3;
            this.textBox30.Text = "Book ID:";
            // 
            // textBox31
            // 
            this.textBox31.Location = new System.Drawing.Point(60, -12);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(459, 26);
            this.textBox31.TabIndex = 4;
            // 
            // textBox32
            // 
            this.textBox32.Location = new System.Drawing.Point(-61, -12);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(100, 26);
            this.textBox32.TabIndex = 3;
            this.textBox32.Text = "Book ID:";
            // 
            // Phone_textBox
            // 
            this.Phone_textBox.BackColor = System.Drawing.Color.White;
            this.Phone_textBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Phone_textBox.Location = new System.Drawing.Point(171, 558);
            this.Phone_textBox.Name = "Phone_textBox";
            this.Phone_textBox.Size = new System.Drawing.Size(160, 19);
            this.Phone_textBox.TabIndex = 52;
            // 
            // Phone_Box
            // 
            this.Phone_Box.BackColor = System.Drawing.Color.White;
            this.Phone_Box.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Phone_Box.Font = new System.Drawing.Font("Microsoft YaHei", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Phone_Box.ForeColor = System.Drawing.Color.Black;
            this.Phone_Box.Location = new System.Drawing.Point(50, 558);
            this.Phone_Box.Name = "Phone_Box";
            this.Phone_Box.Size = new System.Drawing.Size(100, 30);
            this.Phone_Box.TabIndex = 51;
            this.Phone_Box.Text = "Phone :";
            // 
            // panel37
            // 
            this.panel37.BackColor = System.Drawing.Color.Black;
            this.panel37.Controls.Add(this.panel38);
            this.panel37.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.panel37.Location = new System.Drawing.Point(710, 546);
            this.panel37.Name = "panel37";
            this.panel37.Size = new System.Drawing.Size(160, 2);
            this.panel37.TabIndex = 59;
            this.panel37.Paint += new System.Windows.Forms.PaintEventHandler(this.panel37_Paint);
            // 
            // panel38
            // 
            this.panel38.Controls.Add(this.panel39);
            this.panel38.Controls.Add(this.textBox49);
            this.panel38.Controls.Add(this.textBox50);
            this.panel38.ForeColor = System.Drawing.Color.Yellow;
            this.panel38.Location = new System.Drawing.Point(60, 12);
            this.panel38.Name = "panel38";
            this.panel38.Size = new System.Drawing.Size(459, 2);
            this.panel38.TabIndex = 5;
            // 
            // panel39
            // 
            this.panel39.Controls.Add(this.panel40);
            this.panel39.Controls.Add(this.textBox41);
            this.panel39.Controls.Add(this.textBox42);
            this.panel39.ForeColor = System.Drawing.Color.Yellow;
            this.panel39.Location = new System.Drawing.Point(60, 12);
            this.panel39.Name = "panel39";
            this.panel39.Size = new System.Drawing.Size(459, 2);
            this.panel39.TabIndex = 5;
            // 
            // panel40
            // 
            this.panel40.Controls.Add(this.panel41);
            this.panel40.Controls.Add(this.textBox20);
            this.panel40.Controls.Add(this.textBox40);
            this.panel40.ForeColor = System.Drawing.Color.Yellow;
            this.panel40.Location = new System.Drawing.Point(60, 12);
            this.panel40.Name = "panel40";
            this.panel40.Size = new System.Drawing.Size(459, 2);
            this.panel40.TabIndex = 5;
            // 
            // panel41
            // 
            this.panel41.ForeColor = System.Drawing.Color.Yellow;
            this.panel41.Location = new System.Drawing.Point(60, 12);
            this.panel41.Name = "panel41";
            this.panel41.Size = new System.Drawing.Size(459, 2);
            this.panel41.TabIndex = 5;
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(60, -12);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(459, 26);
            this.textBox20.TabIndex = 4;
            // 
            // textBox40
            // 
            this.textBox40.Location = new System.Drawing.Point(-61, -12);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(100, 26);
            this.textBox40.TabIndex = 3;
            this.textBox40.Text = "Book ID:";
            // 
            // textBox41
            // 
            this.textBox41.Location = new System.Drawing.Point(60, -12);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(459, 26);
            this.textBox41.TabIndex = 4;
            // 
            // textBox42
            // 
            this.textBox42.Location = new System.Drawing.Point(-61, -12);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(100, 26);
            this.textBox42.TabIndex = 3;
            this.textBox42.Text = "Book ID:";
            // 
            // textBox49
            // 
            this.textBox49.Location = new System.Drawing.Point(60, -12);
            this.textBox49.Name = "textBox49";
            this.textBox49.Size = new System.Drawing.Size(459, 26);
            this.textBox49.TabIndex = 4;
            // 
            // textBox50
            // 
            this.textBox50.Location = new System.Drawing.Point(-61, -12);
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new System.Drawing.Size(100, 26);
            this.textBox50.TabIndex = 3;
            this.textBox50.Text = "Book ID:";
            // 
            // Book2_textBox
            // 
            this.Book2_textBox.BackColor = System.Drawing.Color.White;
            this.Book2_textBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Book2_textBox.Location = new System.Drawing.Point(710, 522);
            this.Book2_textBox.Name = "Book2_textBox";
            this.Book2_textBox.Size = new System.Drawing.Size(160, 19);
            this.Book2_textBox.TabIndex = 58;
            this.Book2_textBox.TextChanged += new System.EventHandler(this.textBox51_TextChanged);
            // 
            // Book2_Box
            // 
            this.Book2_Box.BackColor = System.Drawing.Color.White;
            this.Book2_Box.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Book2_Box.Font = new System.Drawing.Font("Microsoft YaHei", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Book2_Box.ForeColor = System.Drawing.Color.Black;
            this.Book2_Box.Location = new System.Drawing.Point(589, 522);
            this.Book2_Box.Name = "Book2_Box";
            this.Book2_Box.Size = new System.Drawing.Size(100, 30);
            this.Book2_Box.TabIndex = 57;
            this.Book2_Box.Text = "Book 2 :";
            this.Book2_Box.TextChanged += new System.EventHandler(this.textBox52_TextChanged);
            // 
            // panel52
            // 
            this.panel52.BackColor = System.Drawing.Color.Black;
            this.panel52.Controls.Add(this.panel53);
            this.panel52.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.panel52.Location = new System.Drawing.Point(544, 458);
            this.panel52.Name = "panel52";
            this.panel52.Size = new System.Drawing.Size(147, 2);
            this.panel52.TabIndex = 62;
            // 
            // panel53
            // 
            this.panel53.Controls.Add(this.panel54);
            this.panel53.Controls.Add(this.textBox76);
            this.panel53.Controls.Add(this.textBox77);
            this.panel53.ForeColor = System.Drawing.Color.Yellow;
            this.panel53.Location = new System.Drawing.Point(60, 12);
            this.panel53.Name = "panel53";
            this.panel53.Size = new System.Drawing.Size(459, 2);
            this.panel53.TabIndex = 5;
            // 
            // panel54
            // 
            this.panel54.Controls.Add(this.panel55);
            this.panel54.Controls.Add(this.textBox74);
            this.panel54.Controls.Add(this.textBox75);
            this.panel54.ForeColor = System.Drawing.Color.Yellow;
            this.panel54.Location = new System.Drawing.Point(60, 12);
            this.panel54.Name = "panel54";
            this.panel54.Size = new System.Drawing.Size(459, 2);
            this.panel54.TabIndex = 5;
            // 
            // panel55
            // 
            this.panel55.Controls.Add(this.panel56);
            this.panel55.Controls.Add(this.textBox72);
            this.panel55.Controls.Add(this.textBox73);
            this.panel55.ForeColor = System.Drawing.Color.Yellow;
            this.panel55.Location = new System.Drawing.Point(60, 12);
            this.panel55.Name = "panel55";
            this.panel55.Size = new System.Drawing.Size(459, 2);
            this.panel55.TabIndex = 5;
            // 
            // panel56
            // 
            this.panel56.ForeColor = System.Drawing.Color.Yellow;
            this.panel56.Location = new System.Drawing.Point(60, 12);
            this.panel56.Name = "panel56";
            this.panel56.Size = new System.Drawing.Size(459, 2);
            this.panel56.TabIndex = 5;
            // 
            // textBox72
            // 
            this.textBox72.Location = new System.Drawing.Point(60, -12);
            this.textBox72.Name = "textBox72";
            this.textBox72.Size = new System.Drawing.Size(459, 26);
            this.textBox72.TabIndex = 4;
            // 
            // textBox73
            // 
            this.textBox73.Location = new System.Drawing.Point(-61, -12);
            this.textBox73.Name = "textBox73";
            this.textBox73.Size = new System.Drawing.Size(100, 26);
            this.textBox73.TabIndex = 3;
            this.textBox73.Text = "Book ID:";
            // 
            // textBox74
            // 
            this.textBox74.Location = new System.Drawing.Point(60, -12);
            this.textBox74.Name = "textBox74";
            this.textBox74.Size = new System.Drawing.Size(459, 26);
            this.textBox74.TabIndex = 4;
            // 
            // textBox75
            // 
            this.textBox75.Location = new System.Drawing.Point(-61, -12);
            this.textBox75.Name = "textBox75";
            this.textBox75.Size = new System.Drawing.Size(100, 26);
            this.textBox75.TabIndex = 3;
            this.textBox75.Text = "Book ID:";
            // 
            // textBox76
            // 
            this.textBox76.Location = new System.Drawing.Point(60, -12);
            this.textBox76.Name = "textBox76";
            this.textBox76.Size = new System.Drawing.Size(459, 26);
            this.textBox76.TabIndex = 4;
            // 
            // textBox77
            // 
            this.textBox77.Location = new System.Drawing.Point(-61, -12);
            this.textBox77.Name = "textBox77";
            this.textBox77.Size = new System.Drawing.Size(100, 26);
            this.textBox77.TabIndex = 3;
            this.textBox77.Text = "Book ID:";
            // 
            // Br_id_textBox
            // 
            this.Br_id_textBox.BackColor = System.Drawing.Color.White;
            this.Br_id_textBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Br_id_textBox.Location = new System.Drawing.Point(544, 434);
            this.Br_id_textBox.Name = "Br_id_textBox";
            this.Br_id_textBox.Size = new System.Drawing.Size(147, 19);
            this.Br_id_textBox.TabIndex = 61;
            // 
            // Br_ID_Box
            // 
            this.Br_ID_Box.BackColor = System.Drawing.Color.White;
            this.Br_ID_Box.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Br_ID_Box.Font = new System.Drawing.Font("Microsoft YaHei", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Br_ID_Box.ForeColor = System.Drawing.Color.Black;
            this.Br_ID_Box.Location = new System.Drawing.Point(381, 432);
            this.Br_ID_Box.Name = "Br_ID_Box";
            this.Br_ID_Box.Size = new System.Drawing.Size(137, 30);
            this.Br_ID_Box.TabIndex = 60;
            this.Br_ID_Box.Text = "Borrower ID :";
            // 
            // Borrowers_UserControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.BackgroundImage = global::Library_DBMS.Properties.Resources.l121;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Controls.Add(this.panel52);
            this.Controls.Add(this.Br_id_textBox);
            this.Controls.Add(this.Br_ID_Box);
            this.Controls.Add(this.panel37);
            this.Controls.Add(this.Book2_textBox);
            this.Controls.Add(this.Book2_Box);
            this.Controls.Add(this.panel27);
            this.Controls.Add(this.Book1_textBox);
            this.Controls.Add(this.Book1_Box);
            this.Controls.Add(this.panel32);
            this.Controls.Add(this.Phone_textBox);
            this.Controls.Add(this.Phone_Box);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.Clear_button);
            this.Controls.Add(this.Delete_button);
            this.Controls.Add(this.AddNew_button);
            this.Controls.Add(this.SearchBorrower_button);
            this.Controls.Add(this.panel12);
            this.Controls.Add(this.Address_textBox);
            this.Controls.Add(this.Address_Box);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.Name_textBox);
            this.Controls.Add(this.Name_Box);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Borrower_No_textBox);
            this.Controls.Add(this.BookID_Box);
            this.Name = "Borrowers_UserControl";
            this.Size = new System.Drawing.Size(1076, 681);
            this.Load += new System.EventHandler(this.Borrowers_UserControl_Load);
            this.panel12.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel27.ResumeLayout(false);
            this.panel28.ResumeLayout(false);
            this.panel28.PerformLayout();
            this.panel29.ResumeLayout(false);
            this.panel29.PerformLayout();
            this.panel30.ResumeLayout(false);
            this.panel30.PerformLayout();
            this.panel32.ResumeLayout(false);
            this.panel33.ResumeLayout(false);
            this.panel33.PerformLayout();
            this.panel34.ResumeLayout(false);
            this.panel34.PerformLayout();
            this.panel35.ResumeLayout(false);
            this.panel35.PerformLayout();
            this.panel37.ResumeLayout(false);
            this.panel38.ResumeLayout(false);
            this.panel38.PerformLayout();
            this.panel39.ResumeLayout(false);
            this.panel39.PerformLayout();
            this.panel40.ResumeLayout(false);
            this.panel40.PerformLayout();
            this.panel52.ResumeLayout(false);
            this.panel53.ResumeLayout(false);
            this.panel53.PerformLayout();
            this.panel54.ResumeLayout(false);
            this.panel54.PerformLayout();
            this.panel55.ResumeLayout(false);
            this.panel55.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Clear_button;
        private System.Windows.Forms.Button Delete_button;
        private System.Windows.Forms.Button AddNew_button;
        private System.Windows.Forms.Button SearchBorrower_button;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox Address_textBox;
        private System.Windows.Forms.TextBox Address_Box;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox Name_textBox;
        private System.Windows.Forms.TextBox Name_Box;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox Borrower_No_textBox;
        private System.Windows.Forms.TextBox BookID_Box;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox Book1_textBox;
        private System.Windows.Forms.TextBox Book1_Box;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.Panel panel36;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox Phone_textBox;
        private System.Windows.Forms.TextBox Phone_Box;
        private System.Windows.Forms.Panel panel37;
        private System.Windows.Forms.Panel panel38;
        private System.Windows.Forms.Panel panel39;
        private System.Windows.Forms.Panel panel40;
        private System.Windows.Forms.Panel panel41;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.TextBox textBox49;
        private System.Windows.Forms.TextBox textBox50;
        private System.Windows.Forms.TextBox Book2_textBox;
        private System.Windows.Forms.TextBox Book2_Box;
        private System.Windows.Forms.Panel panel52;
        private System.Windows.Forms.Panel panel53;
        private System.Windows.Forms.Panel panel54;
        private System.Windows.Forms.Panel panel55;
        private System.Windows.Forms.Panel panel56;
        private System.Windows.Forms.TextBox textBox72;
        private System.Windows.Forms.TextBox textBox73;
        private System.Windows.Forms.TextBox textBox74;
        private System.Windows.Forms.TextBox textBox75;
        private System.Windows.Forms.TextBox textBox76;
        private System.Windows.Forms.TextBox textBox77;
        private System.Windows.Forms.TextBox Br_id_textBox;
        private System.Windows.Forms.TextBox Br_ID_Box;
    }
}
